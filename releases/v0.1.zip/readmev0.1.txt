####ARTTECH

##Version 0.1
Release date - 01/10/2016

#inital realese
#install TMRaudio library zip -attached.
#8bit sampled wav audio file support.
#simple audio playback on ultrasonic value conditions.
 


