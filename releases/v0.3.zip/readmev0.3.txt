####ARTTECH

##Version 0.3
Release date - 12/10/2016

#beta realese
#install TMRaudio library zip -attached.
#8bit sampled wav audio file support.
#simple audio playback on ultrasonic value conditions.
#minimal change for checking ultrasonic values to determine the audio playing state.


