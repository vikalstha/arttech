####ARTTECH

##Version 0.2
Release date - 10/10/2016

#beta relese
#install TMRaudio library zip -attached.
#8bit sampled wav audio file support.
#simple audio playback on ultrasonic value conditions.
#conditions for loop audio playback check.Detection of ~realtime human detection.